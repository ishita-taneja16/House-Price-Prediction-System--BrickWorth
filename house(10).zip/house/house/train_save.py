import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt

# 1. Load dataset
df = pd.read_csv("train_final.csv", sep='\t')

print(df.columns)
print(df.head())

# Convert SalePrice to numeric (remove commas)
df['SalePrice'] = df['SalePrice'].astype(str).str.replace(',', '').astype(float)

# --- Outlier removal: keep prices between 1st and 99th percentile ---
q_low = df['SalePrice'].quantile(0.01)
q_high = df['SalePrice'].quantile(0.99)
df_filtered = df[(df['SalePrice'] >= q_low) & (df['SalePrice'] <= q_high)]

print(f"Removed outliers outside price range: {q_low} to {q_high}")
print(f"Filtered dataset size: {df_filtered.shape}")

# Convert binary columns (0/1) to Yes/No on filtered data
binary_cols = ['CornerHouse', 'ParkFacing', 'MainRoadConnected']
for col in binary_cols:
    if df_filtered[col].dtype in [np.int64, np.float64]:
        df_filtered[col] = df_filtered[col].map({1: 'Yes', 0: 'No'})

# 2. Apply log-transform on target (filtered data)
df_filtered['LogSalePrice'] = np.log(df_filtered['SalePrice'])

# 3. Features & Target (use LogSalePrice now)
target_column = "LogSalePrice"
X = df_filtered.drop(columns=['SalePrice', target_column])
y = df_filtered[target_column]

# 4. Identify column types
numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
categorical_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()

# 5. Preprocessing
imputer = SimpleImputer(strategy="mean")
X_num = pd.DataFrame(imputer.fit_transform(X[numeric_cols]), columns=numeric_cols)

encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
X_cat_encoded = pd.DataFrame(
    encoder.fit_transform(X[categorical_cols]),
    columns=encoder.get_feature_names_out(categorical_cols)
)

X_final = pd.concat(
    [X_num.reset_index(drop=True), X_cat_encoded.reset_index(drop=True)],
    axis=1
)

# 6. Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_final, y, test_size=0.2, random_state=42)

# 7. Train Models
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=200, random_state=42),
    "XGBoost": XGBRegressor(n_estimators=300, learning_rate=0.1, max_depth=6, random_state=42)
}

scores = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    scores[name] = r2_score(y_test, y_pred)

# 8. Pick best model
best_model_name = max(scores, key=scores.get)
best_model = models[best_model_name]

print("Model Comparison (R² score):")
for model_name, score in scores.items():
    print(f"{model_name}: {score:.4f}")
print(f"\nBest Model: {best_model_name}")

# 9. Evaluate and visualize predicted vs actual (on original price scale)
y_pred_log = best_model.predict(X_test)
y_pred = np.exp(y_pred_log)
y_true = np.exp(y_test)

plt.figure(figsize=(8, 6))
plt.scatter(y_true, y_pred, alpha=0.5, color='blue')
plt.plot([y_true.min(), y_true.max()], [y_true.min(), y_true.max()], 'r--', linewidth=2)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual vs Predicted House Prices')
plt.tight_layout()
plt.show()

# 10. Save artifacts (trained on filtered data)
pickle.dump(best_model, open("model.pkl", "wb"))
pickle.dump(encoder, open("encoder.pkl", "wb"))
pickle.dump(imputer, open("imputer.pkl", "wb"))

print("Training complete. Files saved: model.pkl, encoder.pkl, imputer.pkl")

# Save feature names order
feature_order = X_final.columns.tolist()
pickle.dump(feature_order, open("feature_order.pkl", "wb"))
pickle.dump(numeric_cols, open("numeric_cols.pkl", "wb"))
pickle.dump(categorical_cols, open("categorical_cols.pkl", "wb"))

# 11. Manual feature importance visualization (optional)
feature_importances = {
    'GrLivArea': 0.35,
    'GrLivArea_sq': 0.25,
    'OverallQual': 0.15,
    'YearBuilt': 0.10,
    'MainRoadConnected_Yes': 0.05,
    'ParkFacing_Yes': 0.03,
    'CornerHouse_Yes': 0.02,
    'BedroomAbvGr': 0.02,
    'TotalBsmtSF': 0.01,
    'GarageCars': 0.01,
    'FullBath': 0.01
}

df_importances = pd.DataFrame(
    list(feature_importances.items()),
    columns=['Feature', 'Importance']
).sort_values(by='Importance', ascending=False)

plt.figure(figsize=(10, 6))
plt.barh(df_importances['Feature'], df_importances['Importance'], color='skyblue')
plt.xlabel('Importance')
plt.ylabel('Feature')
plt.title('Top Feature Importances (Manual)')
plt.gca().invert_yaxis()
plt.tight_layout()
plt.show()
