from django.db import models

# Create your models here.
from django.db import models

class House(models.Model):
    GrLivArea = models.FloatField()
    OverallQual = models.IntegerField()
    BedroomAbvGr = models.IntegerField()
    KitchenAbvGr = models.IntegerField()
    FullBath = models.IntegerField()
    TotRmsAbvGrd = models.IntegerField()
    GarageCars = models.IntegerField()
    YearBuilt = models.IntegerField()
    Storey = models.IntegerField()
    Neighborhood = models.CharField(max_length=100)
    CornerHouse = models.CharField(max_length=10)      # Yes / No
    ParkFacing = models.CharField(max_length=10)       # Yes / No
    MainRoad = models.CharField(max_length=10)         # Yes / No
    SalePrice = models.FloatField()
