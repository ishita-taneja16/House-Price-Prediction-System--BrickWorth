# chatbot

faq_responses = {
    "how is price calculated": "We use machine learning models trained on real data, considering area, location, bedrooms, etc.",
    "what models do you use": "We use Linear Regression, Random Forest, and XGBoost to predict prices. Additionally, this project contains Visualization and Model Comparision",
    "what is mae": "MAE means Mean Absolute Error, the average difference between predicted and actual prices.",
    "what is rmse": "RMSE means Root Mean Squared Error; it penalizes bigger errors more.",
    "can i predict rent": "I am sorry, but you couldn't predict rent as this is basic application. The developers are looking into all possible enhancements.",
    "which areas are most expensive": "Usually premium sectors in Chandigarh and Mohali have the highest prices.",
    "what are premium sectors of chandigarh": "Usually premium sectors in Chandigarh are Sector 7, Sector 8, Sector 10, but according to dataset I have, premium sector is Sector 36",
    "what are premium sectors of mohali": "Usually premium sectors in Mohali are Sector 79, Sector 80, Sector 82, but according to dataset I have, premium sector is Phase 3B2",
    "hello": "Hey! How may I help you?",
    "hi": "Hey! How may I help you?",
    "hey": "Hey! How may I help you?",
    "yo": "Hey! How may I help you?",
    "how is model trained": "Model is trained using 3 Regression Algorithms: Linear regression, RandomForest Regressor and XGBoost Regressor. However, upon comparing them Linear Regression was most accurate, therefore, whole model is based on it.",
    "what are the flaws of this model" : "This model is basic prediction model, therefore, it wasn't able to predict accurate prices. It also has data for only 2 regions which ca be enhanced in future."
}

def chatbot_response(user_question):
    user_question = user_question.lower()
    for key in faq_responses:
        if key in user_question:
            return faq_responses[key]
    return "Sorry, I don't understand that yet. Please ask something else!"
