from django.urls import path
from . import views

urlpatterns = [
    
    path('', views.intro, name='intro'),
    path('index', views.index, name='index'),
    path('predict/', views.predict, name='predict'),
    path('map/', views.map_view, name='map'),
      path('maph/', views.maph_view, name='maph'),
    path('chatbot/', views.chatbot_view, name='chatbot'),
     path('modern/', views.modern_view, name='modern'),
    path('luxury/', views.luxury_view, name='luxury'),
    path('eco/', views.eco_view, name='eco'),
]
