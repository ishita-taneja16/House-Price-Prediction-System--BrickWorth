import os
import pickle
import pandas as pd
import numpy as np
from django.shortcuts import render
from django.http import JsonResponse
from .chatbot import chatbot_response

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(os.path.dirname(BASE_DIR)) 

# Load ML model and preprocessors
model = pickle.load(open(os.path.join(ROOT_DIR, 'model.pkl'), 'rb'))
imputer = pickle.load(open(os.path.join(ROOT_DIR, 'imputer.pkl'), 'rb'))
encoder = pickle.load(open(os.path.join(ROOT_DIR, 'encoder.pkl'), 'rb'))
feature_order = pickle.load(open(os.path.join(ROOT_DIR, 'feature_order.pkl'), 'rb'))
numeric_cols = pickle.load(open(os.path.join(ROOT_DIR, 'numeric_cols.pkl'), 'rb'))
categorical_cols = pickle.load(open(os.path.join(ROOT_DIR, 'categorical_cols.pkl'), 'rb'))

def format_in_indian_currency(number):
    s = str(int(number))
    if len(s) <= 3:
        return s
    else:
        last_three = s[-3:]
        other = s[:-3]
        result = ''
        while len(other) > 2:
            result = ',' + other[-2:] + result
            other = other[:-2]
        result = other + result if other else result
        return result + ',' + last_three

def index(request):
    location = request.GET.get('location', '')
    sublocation = request.GET.get('sublocation', '')
    min_price = request.GET.get('min', '')
    max_price = request.GET.get('max', '')
    return render(request, 'index.html', {
        'location': location,
        'sublocation': sublocation,
        'min_price': min_price,
        'max_price': max_price,
    })

def map_view(request):
    location = request.GET.get('location', '')
    house_type = request.GET.get('house_type', '')
    if location == 'Himachal':
        return render(request, 'maph.html', {'house_type': house_type})
    else:
        return render(request, 'map.html', {'house_type': house_type})

def maph_view(request):
    house_type = request.GET.get('house_type', '')
    return render(request, 'maph.html', {'house_type': house_type})
def predict(request):
    if request.method == 'POST':
        try:
            # Get all form values
            area = float(request.POST['GrLivArea'])
            quality = int(request.POST['overall_qual'])
            bedroom = int(request.POST['bedroom'])
            kitchen = int(request.POST['kitchen'])
            bathroom = int(request.POST['bathroom'])
            year = int(request.POST['year_built'])
            garage = int(request.POST['garage'])
            rooms = int(request.POST['rooms'])
            storey = int(request.POST['storey'])

            location = request.POST.get('Neighborhood')
            sublocation = request.POST.get('Sector')
            house_type = request.POST.get('house_type')
            park = request.POST.get('ParkFacing', 'No')
            mainroad = request.POST.get('MainRoadConnected', 'No')
            corner = request.POST.get('CornerHouse', 'No')
   
            # House type sqft validation
            validation_rules = {
                'modern': {
                    'min': 1500,
                    'max': 2000,
                    'error': "Modern homes must be between 1500-2000 sqft",
                    'range': "1500-2000 sqft"
                },
                'luxury': {
                    'min': 2100,
                    'max': float('inf'),
                    'error': "Luxury villas require minimum 2100 sqft",
                    'range': "2100+ sqft"
                },
                'eco': {
                    'min': 800,
                    'max': 1500,
                    'error': "Eco homes must be between 800-1500 sqft",
                    'range': "800-1500 sqft"
                }
            }
            
            # Validate only if house_type is specified
            if house_type in validation_rules:
                rule = validation_rules[house_type]
                if not (rule['min'] <= area <= rule['max']):
                    response_data = {
                        'out_of_range': True,
                        'error': f"{rule['error']} (You entered: {area} sqft)",
                        'allowed_range': rule['range']
                    }
                    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                        return JsonResponse(response_data)
                    return render(request, 'index.html', {**response_data, **request.POST.dict()})

            # Create DataFrame for prediction
            df = pd.DataFrame([{
                'GrLivArea': area,
                'OverallQual': quality,
                'BedroomAbvGr': bedroom,
                'KitchenAbvGr': kitchen,
                'GarageCars': garage,
                'FullBath': bathroom,
                'TotRmsAbvGrd': rooms,
                'YearBuilt': year,
                'Sector': sublocation,
                'Neighborhood': location,
                'Storey': storey,
                'ParkFacing': park,
                'CornerHouse': corner,
                'MainRoadConnected': mainroad
            }])

            # Preprocess data
            X_num = pd.DataFrame(imputer.transform(df[numeric_cols]), columns=numeric_cols)
            X_cat = df[categorical_cols].fillna('Missing')
            X_cat_encoded = pd.DataFrame(
                encoder.transform(X_cat), 
                columns=encoder.get_feature_names_out(categorical_cols)
            )
            X_final = pd.concat([X_num.reset_index(drop=True), X_cat_encoded.reset_index(drop=True)], axis=1)

            # Match column order with training (fill missing with 0)
            X_final = X_final.reindex(columns=feature_order, fill_value=0)

            # Predict price (log scale)
            log_predicted_price = model.predict(X_final)[0]
            predicted_price = np.exp(log_predicted_price)
            
            # Apply calibration factor
            calibration_factor = 0.55
            predicted_price = predicted_price * calibration_factor

            # Calculate range
            lower = predicted_price * 0.95
            upper = predicted_price * 1.17

            response_data = {
                'prediction_text': f"Predicted Price: {format_in_indian_currency(predicted_price)}",
                'estimated_range': f"{format_in_indian_currency(lower)} – {format_in_indian_currency(upper)}",
                'bedroom': bedroom,
                'location': location,
                'sublocation': sublocation
            }

            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse(response_data)
            return render(request, 'index.html', {**response_data, **request.POST.dict()})

        except Exception as e:
            error_response = {'error': f"Error during prediction: {str(e)}"}
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse(error_response, status=400)
            return render(request, 'index.html', error_response)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'error': 'Invalid request method'}, status=400)
    return render(request, 'index.html')

def chatbot_view(request):
    if request.method == "POST":
        user_question = request.POST.get('question', '')
        answer = chatbot_response(user_question)
        return JsonResponse({'answer': answer})
    return JsonResponse({'answer': "Invalid request"})

def intro(request):
    return render(request, 'intro.html')

def modern_view(request):
    return render(request, 'modern.html', {'house_type': 'modern'})

def luxury_view(request):
    return render(request, 'luxury.html', {'house_type': 'luxury'})

def eco_view(request):
    return render(request, 'eco.html', {'house_type': 'eco'})